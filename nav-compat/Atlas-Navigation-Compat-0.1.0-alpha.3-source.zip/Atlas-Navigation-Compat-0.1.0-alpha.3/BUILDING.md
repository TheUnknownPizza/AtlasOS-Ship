# Building

Java 21 is required.

Windows:

```text
gradlew.bat clean build
```

Linux/macOS:

```text
./gradlew clean build
```

Expected output:

```text
build/libs/atlas-navigation-compat-0.1.0-alpha.3.jar
```

If Gradle cannot resolve Simulated, confirm that `https://maven.ryanhcode.dev/releases` is reachable. The dependency coordinates match those used by Create: Avionics 0.5.2.
