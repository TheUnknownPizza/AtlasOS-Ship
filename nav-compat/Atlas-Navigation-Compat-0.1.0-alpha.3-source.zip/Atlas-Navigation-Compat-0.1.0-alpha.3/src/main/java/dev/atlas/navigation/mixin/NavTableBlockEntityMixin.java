package dev.atlas.navigation.mixin;

import dev.atlas.navigation.api.AtlasTargetAccess;
import dev.simulated_team.simulated.content.blocks.nav_table.NavTableBlockEntity;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Gives the stock Simulated Navigation Table a second, programmatic target source.
 *
 * Physical target items remain untouched. When an Atlas target is active it wins;
 * clearing it immediately returns control to the normal held-item target on the
 * next table tick. The Atlas target is world-space, which is important for a table
 * mounted on a moving Sable sublevel.
 */
@Mixin(NavTableBlockEntity.class)
public abstract class NavTableBlockEntityMixin implements AtlasTargetAccess {
    private static final String NBT_ACTIVE = "AtlasTargetActive";
    private static final String NBT_X = "AtlasTargetX";
    private static final String NBT_Y = "AtlasTargetY";
    private static final String NBT_Z = "AtlasTargetZ";
    private static final String NBT_LABEL = "AtlasTargetLabel";

    @Shadow @Nullable public Vec3 currentTarget;
    @Shadow private double distanceToTarget;
    @Shadow private double lastDistanceToTarget;
    @Shadow public abstract Vec3 getProjectedSelfPos();

    @Unique private boolean atlas$targetActive;
    @Unique private double atlas$targetX;
    @Unique private double atlas$targetY;
    @Unique private double atlas$targetZ;
    @Unique private String atlas$targetLabel = "";
    @Unique private int atlas$distanceTicks;

    @Unique
    private Vec3 atlas$targetVec() {
        return new Vec3(this.atlas$targetX, this.atlas$targetY, this.atlas$targetZ);
    }

    @Override
    public void atlas$setTarget(final Vec3 worldTarget, final String label) {
        if (worldTarget == null || !Double.isFinite(worldTarget.x) || !Double.isFinite(worldTarget.y)
                || !Double.isFinite(worldTarget.z)) {
            throw new IllegalArgumentException("Atlas navigation target must contain finite coordinates");
        }

        this.atlas$targetX = worldTarget.x;
        this.atlas$targetY = worldTarget.y;
        this.atlas$targetZ = worldTarget.z;
        this.atlas$targetLabel = label == null ? "" : label.substring(0, Math.min(label.length(), 96));
        this.atlas$targetActive = true;
        this.atlas$distanceTicks = 11; // force a distance sample on the next tick
        this.currentTarget = worldTarget;

        final NavTableBlockEntity self = (NavTableBlockEntity) (Object) this;
        this.lastDistanceToTarget = this.distanceToTarget;
        this.distanceToTarget = self.getProjectedSelfPos().distanceTo(worldTarget);
        self.setChanged();
    }

    @Override
    public void atlas$clearTarget() {
        this.atlas$targetActive = false;
        this.atlas$targetLabel = "";
        this.atlas$distanceTicks = 0;
        this.currentTarget = null;
        ((NavTableBlockEntity) (Object) this).setChanged();
    }

    @Override
    public boolean atlas$hasTarget() {
        return this.atlas$targetActive;
    }

    @Override
    public @Nullable Vec3 atlas$getTarget() {
        return this.atlas$targetActive ? this.atlas$targetVec() : null;
    }

    @Override
    public String atlas$getTargetLabel() {
        return this.atlas$targetLabel;
    }

    @Inject(method = "updateTarget", at = @At("TAIL"))
    private void atlas$overridePhysicalTarget(final CallbackInfo ci) {
        if (this.atlas$targetActive) this.currentTarget = this.atlas$targetVec();
    }

    @Inject(method = "getTargetPosition", at = @At("HEAD"), cancellable = true)
    private void atlas$worldTargetPosition(final boolean project, final CallbackInfoReturnable<Vec3> cir) {
        // Atlas coordinates are already in projected/world space. Returning them directly
        // prevents Sable from projecting them a second time while the ship is assembled.
        if (this.atlas$targetActive) cir.setReturnValue(this.atlas$targetVec());
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void atlas$sampleDistance(final CallbackInfo ci) {
        if (!this.atlas$targetActive) return;

        final NavTableBlockEntity self = (NavTableBlockEntity) (Object) this;
        if (self.getLevel() == null || self.getLevel().isClientSide) return;

        if (this.atlas$distanceTicks > 10) {
            this.atlas$distanceTicks = 0;
            this.lastDistanceToTarget = this.distanceToTarget;
            this.distanceToTarget = self.getProjectedSelfPos().distanceTo(this.atlas$targetVec());
        }
        this.atlas$distanceTicks++;
    }

    @Inject(method = "write", at = @At("TAIL"))
    private void atlas$writeTarget(final CompoundTag tag, final HolderLookup.Provider registries,
                                   final boolean clientPacket, final CallbackInfo ci) {
        tag.putBoolean(NBT_ACTIVE, this.atlas$targetActive);
        if (!this.atlas$targetActive) return;
        tag.putDouble(NBT_X, this.atlas$targetX);
        tag.putDouble(NBT_Y, this.atlas$targetY);
        tag.putDouble(NBT_Z, this.atlas$targetZ);
        tag.putString(NBT_LABEL, this.atlas$targetLabel);
    }

    @Inject(method = "read", at = @At("TAIL"))
    private void atlas$readTarget(final CompoundTag tag, final HolderLookup.Provider registries,
                                  final boolean clientPacket, final CallbackInfo ci) {
        this.atlas$targetActive = tag.getBoolean(NBT_ACTIVE);
        if (!this.atlas$targetActive) {
            this.atlas$targetLabel = "";
            return;
        }

        this.atlas$targetX = tag.getDouble(NBT_X);
        this.atlas$targetY = tag.getDouble(NBT_Y);
        this.atlas$targetZ = tag.getDouble(NBT_Z);
        this.atlas$targetLabel = tag.getString(NBT_LABEL);
        this.currentTarget = this.atlas$targetVec();
        this.atlas$distanceTicks = 11;
    }
}
