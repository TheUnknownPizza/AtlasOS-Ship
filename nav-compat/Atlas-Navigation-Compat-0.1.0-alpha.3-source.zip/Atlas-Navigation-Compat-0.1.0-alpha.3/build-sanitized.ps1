$ErrorActionPreference = "Continue"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$outLog = Join-Path $root "build-sanitized.log"
Remove-Item $outLog -Force -ErrorAction SilentlyContinue

$profile = $env:USERPROFILE
$user = $env:USERNAME

Write-Host "Atlas Navigation Compatibility: starting Gradle build..."
Write-Host "Output is shown live and copied to build-sanitized.log."
Write-Host "User-profile details are replaced before either is displayed or saved."
Write-Host ""

& .\gradlew.bat clean build --stacktrace --console=plain 2>&1 | ForEach-Object {
    $line = $_.ToString()
    if ($profile) { $line = $line.Replace($profile, "<USERPROFILE>") }
    if ($user) { $line = $line.Replace($user, "<USERNAME>") }

    Write-Host $line
    Add-Content -LiteralPath $outLog -Value $line -Encoding UTF8
}

$exitCode = $LASTEXITCODE
Write-Host ""
Write-Host "Sanitized log written to: $outLog"
Write-Host "Gradle exit code: $exitCode"
exit $exitCode
