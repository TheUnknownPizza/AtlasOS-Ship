# Atlas Navigation Compatibility 0.1.0-alpha.3

Small compatibility layer for AtlasOS Volume V.

It augments Simulated's existing `navigation_table` peripheral instead of replacing the block or forking Create: Avionics.

## Added Lua methods

```lua
nav.atlasSetTarget(x, z, label)
nav.atlasSetTarget3D(x, y, z, label)
nav.atlasClearTarget()
nav.atlasHasTarget()
nav.atlasGetTarget()
```

`atlasSetTarget(x,z,label)` captures the table's current world Y. AtlasOS therefore keeps altitude with its existing altitude-hold controller while the Navigation Table handles horizontal bearing/distance.

While an Atlas target is active it has priority over a physical map/compass target. `atlasClearTarget()` returns the table to normal physical-item behaviour.

The programmable target is persisted in the Navigation Table block entity and is stored in world/projected coordinates, so assembling the table onto a Sable sublevel does not make the destination move with the ship.

## Compatibility target

- Minecraft 1.21.1
- NeoForge 21.1.x
- Simulated 1.2.1
- Create: Avionics 0.5.2 (optional at the Java level, expected by AtlasOS for its richer nav telemetry)
- CC:Tweaked 1.115.1+

This alpha intentionally does **not** change the Navigation Table's item slot. No fake compass, generated clipboard, or inventory swap is needed.
