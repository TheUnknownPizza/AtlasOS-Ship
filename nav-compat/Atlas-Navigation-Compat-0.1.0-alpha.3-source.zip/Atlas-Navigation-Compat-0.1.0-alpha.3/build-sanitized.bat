@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-sanitized.ps1"
set "ATLAS_EXIT=%ERRORLEVEL%"
exit /b %ATLAS_EXIT%
