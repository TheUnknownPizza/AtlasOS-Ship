package dev.atlas.navigation;

import net.neoforged.fml.common.Mod;

@Mod(AtlasNavigation.MOD_ID)
public final class AtlasNavigation {
    public static final String MOD_ID = "atlas_navigation";

    public AtlasNavigation() {
        // All functionality is supplied by narrow compatibility mixins.
    }
}
