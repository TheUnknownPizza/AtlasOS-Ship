package dev.atlas.navigation.api;

import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Added to Simulated's Navigation Table block entity at runtime.
 * Coordinates are stored in projected/world space so a moving Sable sublevel
 * can steer toward a fixed world destination.
 */
public interface AtlasTargetAccess {
    void atlas$setTarget(Vec3 worldTarget, String label);
    void atlas$clearTarget();
    boolean atlas$hasTarget();
    @Nullable Vec3 atlas$getTarget();
    String atlas$getTargetLabel();
}
