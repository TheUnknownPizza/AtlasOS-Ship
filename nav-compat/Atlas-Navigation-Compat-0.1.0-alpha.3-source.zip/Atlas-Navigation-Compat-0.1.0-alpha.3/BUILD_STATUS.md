# Build status

- Source-level Java syntax check: **PASS** (Java 21, minimal API stubs).
- alpha.1 first real Gradle build: **FAILED at compileJava** because Create was missing from the direct compile classpath.
- alpha.2 adds the Create 6.0.10 slim artifact as a direct compile-only dependency; this is intended to resolve all six alpha.1 compiler errors (`SmartBlockEntity`, inherited `setChanged/getLevel`, and the peripheral cast).
- Full NeoForge/Gradle build in the ChatGPT sandbox: **not run successfully** because the sandbox cannot resolve `services.gradle.org` / Maven dependencies.
- Target APIs were checked against Simulated 1.2.1 source and Create: Avionics 0.5.2 source.

The first real build should be run on the normal Atlas development machine with internet access:

```text
gradlew.bat clean build
```

Do not treat alpha.2 as flight-proven until the manual Navigation Table smoke test and AtlasOS Volume V test card pass in Minecraft.


## alpha.3 compile-classpath fix
Added direct compile-only Ponder, Flywheel API, and Registrate dependencies required by Create's slim artifact. This addresses the alpha.2 javac failure on `net.createmod.ponder.api.VirtualBlockEntity` and preloads the other standard Create companion APIs to avoid dependency-whack-a-mole.
