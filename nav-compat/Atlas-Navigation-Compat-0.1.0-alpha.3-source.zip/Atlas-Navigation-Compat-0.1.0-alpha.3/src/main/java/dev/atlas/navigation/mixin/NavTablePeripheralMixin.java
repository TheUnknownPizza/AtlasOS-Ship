package dev.atlas.navigation.mixin;

import dan200.computercraft.api.lua.LuaFunction;
import dev.atlas.navigation.api.AtlasTargetAccess;
import dev.simulated_team.simulated.compat.computercraft.peripherals.NavTablePeripheral;
import dev.simulated_team.simulated.content.blocks.nav_table.NavTableBlockEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;

import java.util.LinkedHashMap;
import java.util.Map;

/** Adds programmatic world-coordinate targets to the existing navigation_table peripheral. */
@Mixin(NavTablePeripheral.class)
public abstract class NavTablePeripheralMixin {
    private NavTableBlockEntity atlas$blockEntity() {
        return (NavTableBlockEntity) ((SimPeripheralAccessor) this).atlas$getBlockEntity();
    }

    private AtlasTargetAccess atlas$access() {
        return (AtlasTargetAccess) this.atlas$blockEntity();
    }

    private static void atlas$validateHorizontal(final double x, final double z) {
        if (!Double.isFinite(x) || !Double.isFinite(z)) {
            throw new IllegalArgumentException("Coordinates must be finite numbers");
        }
        // Minecraft's normal hard coordinate limit is just under +/-30 million.
        if (Math.abs(x) > 29_999_984 || Math.abs(z) > 29_999_984) {
            throw new IllegalArgumentException("Coordinates exceed Minecraft's world limit");
        }
    }

    private static void atlas$validateY(final double y) {
        if (!Double.isFinite(y) || Math.abs(y) > 16_384) {
            throw new IllegalArgumentException("Y coordinate is outside the supported range");
        }
    }

    /**
     * Set a horizontal AtlasOS target. Y is captured from the Navigation Table's
     * current projected/world position so Volume V can keep altitude independently.
     */
    @LuaFunction(mainThread = true)
    public final void atlasSetTarget(final double x, final double z, final String label) {
        atlas$validateHorizontal(x, z);
        final NavTableBlockEntity blockEntity = this.atlas$blockEntity();
        final double y = blockEntity.getProjectedSelfPos().y;
        this.atlas$access().atlas$setTarget(new Vec3(x, y, z), label);
    }

    /** Set an explicit three-dimensional world-space target. */
    @LuaFunction(mainThread = true)
    public final void atlasSetTarget3D(final double x, final double y, final double z, final String label) {
        atlas$validateHorizontal(x, z);
        atlas$validateY(y);
        this.atlas$access().atlas$setTarget(new Vec3(x, y, z), label);
    }

    /** Clear only the Atlas target. A normal map/compass target resumes automatically. */
    @LuaFunction(mainThread = true)
    public final void atlasClearTarget() {
        this.atlas$access().atlas$clearTarget();
    }

    @LuaFunction
    public final boolean atlasHasTarget() {
        return this.atlas$access().atlas$hasTarget();
    }

    /** Return {active,label,x,y,z}. */
    @LuaFunction
    public final Map<String, Object> atlasGetTarget() {
        final AtlasTargetAccess access = this.atlas$access();
        final Map<String, Object> out = new LinkedHashMap<>();
        out.put("active", access.atlas$hasTarget());
        out.put("label", access.atlas$getTargetLabel());
        final Vec3 target = access.atlas$getTarget();
        if (target != null) {
            out.put("x", target.x);
            out.put("y", target.y);
            out.put("z", target.z);
        }
        return out;
    }
}
