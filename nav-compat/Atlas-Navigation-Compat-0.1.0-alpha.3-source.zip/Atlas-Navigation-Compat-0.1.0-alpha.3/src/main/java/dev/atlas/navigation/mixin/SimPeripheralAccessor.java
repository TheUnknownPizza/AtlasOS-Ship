package dev.atlas.navigation.mixin;

import dev.simulated_team.simulated.compat.computercraft.peripherals.SimPeripheral;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SimPeripheral.class)
public interface SimPeripheralAccessor {
    @Accessor("blockEntity")
    BlockEntity atlas$getBlockEntity();
}
